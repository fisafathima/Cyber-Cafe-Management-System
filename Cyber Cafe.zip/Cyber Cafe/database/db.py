import mysql.connector

def connect_db():
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="fisa",
        database="cyber_cafe"
    )

    return connection