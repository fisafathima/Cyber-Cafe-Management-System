def bill_generator():

    number = 1

    while True:

        yield number

        number += 1