def cafe_message(prefix):

    def message(text):

        return f"{prefix} {text}"

    return message