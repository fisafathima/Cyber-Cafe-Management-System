def logger(func):

    def wrapper(*args, **kwargs):

        print(
            f"Running function: {func.__name__}"
        )

        return func(*args, **kwargs)

    return wrapper