import requests
from bs4 import BeautifulSoup


def get_packages():

    url = "https://books.toscrape.com/"

    response = requests.get(url)

    soup = BeautifulSoup(
        response.text,
        "html.parser"
    )

    titles = soup.find_all("h3")

    packages = []

    for title in titles[:5]:

        packages.append(
            title.text.strip()
        )

    return packages