class Bill:

    def __init__(
        self,
        customer_name,
        usage_hours,
        snack_amount
    ):

        self.customer_name = customer_name
        self.usage_hours = usage_hours
        self.snack_amount = snack_amount


    def calculate_total(self):

        usage_charge = self.usage_hours * 50

        total = usage_charge + self.snack_amount

        return total




class VIPBill(Bill):



    def calculate_total(self):

        usage_charge = self.usage_hours * 50

        total = usage_charge + self.snack_amount

        discount = total * 0.10

        return int(total - discount)