class Session:

    def __init__(
        self,
        customer_name,
        pc_number,
        start_time,
        end_time,
        status
    ):

        self.customer_name = customer_name
        self.pc_number = pc_number
        self.start_time = start_time
        self.end_time = end_time
        self.status = status