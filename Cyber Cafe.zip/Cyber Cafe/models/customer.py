class Customer:

    def __init__(self, name, phone, membership):

        self.name = name
        self.phone = phone
        self.membership = membership