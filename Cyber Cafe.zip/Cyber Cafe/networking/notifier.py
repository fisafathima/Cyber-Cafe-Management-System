import socket


def send_notification(message):

    try:

        client = socket.socket(
            socket.AF_INET,
            socket.SOCK_STREAM
        )

        print(
            "Notification Sent:",
            message
        )

        client.close()

    except Exception as e:

        print("Error:", e)