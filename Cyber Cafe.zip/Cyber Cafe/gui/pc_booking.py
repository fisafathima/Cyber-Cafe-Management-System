from tkinter import *
from tkinter import ttk, messagebox

from datetime import datetime

from database.db import connect_db
from models.session import Session


class PCBooking:

    def __init__(self, root):

        self.root = root

        self.root.title("PC Booking")

        self.root.geometry("800x500")

        self.root.config(bg="#1e1e2f")


        Label(
            self.root,
            text="PC Booking System",
            font=("Arial", 20, "bold"),
            bg="#1e1e2f",
            fg="#00ffd5"
        ).pack(pady=20)


        form_frame = Frame(self.root, bg="#2b2b40")

        form_frame.pack(pady=10)




        Label(
            form_frame,
            text="Customer Name",
            bg="#2b2b40",
            fg="white"
        ).grid(row=0, column=0, padx=10, pady=10)

        self.customer_entry = Entry(form_frame, width=30)

        self.customer_entry.grid(row=0, column=1)




        Label(
            form_frame,
            text="PC Number",
            bg="#2b2b40",
            fg="white"
        ).grid(row=1, column=0, padx=10, pady=10)

        self.pc_box = ttk.Combobox(
            form_frame,
            values=[1,2,3,4,5]
        )

        self.pc_box.grid(row=1, column=1)

        self.pc_box.current(0)




        Button(
            self.root,
            text="Start Session",
            bg="#00ffd5",
            width=20,
            command=self.start_session
        ).pack(pady=10)


        Button(
            self.root,
            text="End Session",
            bg="orange",
            width=20,
            command=self.end_session
        ).pack(pady=10)




        self.session_table = ttk.Treeview(
            self.root,
            columns=(
                "ID",
                "Customer",
                "PC",
                "Start",
                "End",
                "Status"
            ),
            show="headings"
        )

        self.session_table.heading("ID", text="ID")
        self.session_table.heading("Customer", text="Customer")
        self.session_table.heading("PC", text="PC")
        self.session_table.heading("Start", text="Start Time")
        self.session_table.heading("End", text="End Time")
        self.session_table.heading("Status", text="Status")

        self.session_table.pack(fill=BOTH, expand=True)

        self.load_sessions()


    def start_session(self):

        customer = self.customer_entry.get()

        pc_number = self.pc_box.get()

        start_time = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        session = Session(
            customer,
            pc_number,
            start_time,
            "",
            "Running"
        )

        try:

            conn = connect_db()

            cursor = conn.cursor()

            query = """
            INSERT INTO sessions(
                customer_name,
                pc_number,
                start_time,
                end_time,
                status
            )
            VALUES(%s,%s,%s,%s,%s)
            """

            values = (
                session.customer_name,
                session.pc_number,
                session.start_time,
                session.end_time,
                session.status
            )

            cursor.execute(query, values)

            conn.commit()

            conn.close()

            messagebox.showinfo(
                "Success",
                "Session Started"
            )

            self.load_sessions()

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )


    def end_session(self):

        selected = self.session_table.focus()

        data = self.session_table.item(selected)

        row = data["values"]

        if not row:

            messagebox.showerror(
                "Error",
                "Select a session"
            )

            return

        session_id = row[0]

        end_time = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        try:

            conn = connect_db()

            cursor = conn.cursor()

            query = """
            UPDATE sessions
            SET end_time=%s,
                status=%s
            WHERE id=%s
            """

            cursor.execute(
                query,
                (end_time, "Completed", session_id)
            )

            conn.commit()

            conn.close()

            messagebox.showinfo(
                "Success",
                "Session Ended"
            )

            self.load_sessions()

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )


    def load_sessions(self):

        for row in self.session_table.get_children():

            self.session_table.delete(row)

        try:

            conn = connect_db()

            cursor = conn.cursor()

            cursor.execute(
                "SELECT * FROM sessions"
            )

            rows = cursor.fetchall()

            for row in rows:

                self.session_table.insert(
                    "",
                    END,
                    values=row
                )

            conn.close()

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )


if __name__ == "__main__":

    root = Tk()

    app = PCBooking(root)

    root.mainloop()