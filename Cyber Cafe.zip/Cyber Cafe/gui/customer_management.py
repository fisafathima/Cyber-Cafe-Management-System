from tkinter import *
from tkinter import ttk, messagebox

from database.db import connect_db
from models.customer import Customer


class CustomerManagement:

    def __init__(self, root):

        self.root = root

        self.root.title("Customer Management")

        self.root.geometry("700x500")

        self.root.config(bg="#1e1e2f")




        Label(
            self.root,
            text="Customer Management",
            font=("Arial", 20, "bold"),
            bg="#1e1e2f",
            fg="#00ffd5"
        ).pack(pady=20)




        form_frame = Frame(self.root, bg="#2b2b40")

        form_frame.pack(pady=10)




        Label(
            form_frame,
            text="Customer Name",
            bg="#2b2b40",
            fg="white"
        ).grid(row=0, column=0, padx=10, pady=10)

        self.name_entry = Entry(form_frame, width=30)

        self.name_entry.grid(row=0, column=1)




        Label(
            form_frame,
            text="Phone",
            bg="#2b2b40",
            fg="white"
        ).grid(row=1, column=0, padx=10, pady=10)

        self.phone_entry = Entry(form_frame, width=30)

        self.phone_entry.grid(row=1, column=1)




        Label(
            form_frame,
            text="Membership",
            bg="#2b2b40",
            fg="white"
        ).grid(row=2, column=0, padx=10, pady=10)

        self.membership_box = ttk.Combobox(
            form_frame,
            values=["Normal", "VIP"]
        )

        self.membership_box.grid(row=2, column=1)

        self.membership_box.current(0)




        Button(
            self.root,
            text="Add Customer",
            bg="#00ffd5",
            fg="black",
            width=20,
            command=self.add_customer
        ).pack(pady=20)


        

        self.customer_table = ttk.Treeview(
            self.root,
            columns=("ID", "Name", "Phone", "Membership"),
            show="headings"
        )

        self.customer_table.heading("ID", text="ID")
        self.customer_table.heading("Name", text="Name")
        self.customer_table.heading("Phone", text="Phone")
        self.customer_table.heading("Membership", text="Membership")

        self.customer_table.pack(fill=BOTH, expand=True)

        self.load_customers()


    def add_customer(self):

        name = self.name_entry.get()
        phone = self.phone_entry.get()
        membership = self.membership_box.get()

        customer = Customer(name, phone, membership)

        try:

            conn = connect_db()

            cursor = conn.cursor()

            query = """
            INSERT INTO customers(name, phone, membership)
            VALUES(%s, %s, %s)
            """

            values = (
                customer.name,
                customer.phone,
                customer.membership
            )

            cursor.execute(query, values)

            conn.commit()

            conn.close()

            messagebox.showinfo(
                "Success",
                "Customer Added Successfully"
            )

            self.load_customers()

        except Exception as e:

            messagebox.showerror(
                "Database Error",
                str(e)
            )


    def load_customers(self):

        for row in self.customer_table.get_children():
            self.customer_table.delete(row)

        try:

            conn = connect_db()

            cursor = conn.cursor()

            cursor.execute("SELECT * FROM customers")

            rows = cursor.fetchall()

            for row in rows:
                self.customer_table.insert("", END, values=row)

            conn.close()

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )


if __name__ == "__main__":

    root = Tk()

    app = CustomerManagement(root)

    root.mainloop()