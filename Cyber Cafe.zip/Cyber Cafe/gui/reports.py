import os
import pandas as pd

from tkinter import *
from tkinter import ttk, messagebox

from database.db import connect_db


class Reports:

    def __init__(self, root):

        self.root = root

        self.root.title("Reports")

        self.root.geometry("800x500")

        self.root.config(bg="#1e1e2f")


        Label(
            self.root,
            text="Reports & Analytics",
            font=("Arial", 20, "bold"),
            bg="#1e1e2f",
            fg="#00ffd5"
        ).pack(pady=20)


        Button(
            self.root,
            text="Load Billing Report",
            bg="#00ffd5",
            fg="black",
            width=25,
            command=self.load_report
        ).pack(pady=10)


        Button(
            self.root,
            text="Export CSV",
            bg="orange",
            fg="black",
            width=25,
            command=self.export_csv
        ).pack(pady=10)


        self.total_label = Label(
            self.root,
            text="",
            font=("Arial", 14, "bold"),
            bg="#1e1e2f",
            fg="white"
        )

        self.total_label.pack(pady=10)


        self.report_table = ttk.Treeview(
            self.root,
            columns=(
                "ID",
                "Customer",
                "Hours",
                "Snacks",
                "Total"
            ),
            show="headings"
        )

        self.report_table.heading("ID", text="ID")
        self.report_table.heading("Customer", text="Customer")
        self.report_table.heading("Hours", text="Hours")
        self.report_table.heading("Snacks", text="Snacks")
        self.report_table.heading("Total", text="Total")

        self.report_table.pack(
            fill=BOTH,
            expand=True
        )


    def load_report(self):

        try:

            conn = connect_db()

            query = """
            SELECT * FROM bills
            """

            cursor = conn.cursor()

            cursor.execute(query)

            rows = cursor.fetchall()

            columns = [
                column[0]
                for column in cursor.description
            ]

            df = pd.DataFrame(rows, columns=columns)

            conn.close()




            for row in self.report_table.get_children():

                self.report_table.delete(row)




            for row in df.values.tolist():

                self.report_table.insert(
                    "",
                    END,
                    values=row
                )




            total_income = df[
                "total_amount"
            ].sum()


            self.total_label.config(
                text=f"Total Income: Rs.{total_income}"
            )


            #

            vip_customers = [
                row[1]
                for row in df.values.tolist()
                if row[4] > 300
            ]


            print("High Paying Customers:")

            for customer in vip_customers:

                print(customer)


        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )


    def export_csv(self):

        try:

            conn = connect_db()

            query = """
            SELECT * FROM bills
            """

            df = pd.read_sql(query, conn)

            conn.close()




            BASE_DIR = os.path.dirname(
                os.path.dirname(__file__)
            )

            report_path = os.path.join(
                BASE_DIR,
                "reports",
                "billing_report.csv"
            )

            os.makedirs(
                os.path.dirname(report_path),
                exist_ok=True
            )




            df.to_csv(
                report_path,
                index=False
            )


            messagebox.showinfo(
                "Success",
                "CSV Exported Successfully"
            )

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )


if __name__ == "__main__":

    root = Tk()

    app = Reports(root)

    root.mainloop()