from tkinter import *
from gui.customer_management import CustomerManagement
from gui.pc_booking import PCBooking
from gui.billing_system import BillingSystem
from gui.reports import Reports
from gui.tools import Tools

class Dashboard:

    def __init__(self, root):

        self.root = root

        self.root.title("Cyber Cafe Dashboard")

        self.root.geometry("800x500")

        self.root.config(bg="black")


        title = Label(
            self.root,
            text="Cyber Cafe Management System",
            font=("Arial", 22, "bold"),
            bg="black",
            fg="white"
        )

        title.pack(pady=20)

        Button(
            self.root,
            text="Customer Management",
            width=25,
            height=2,
            command=self.open_customer_management
        ).pack(pady=10)

        Button(
            self.root,
            text="PC Booking",
            width=25,
            height=2,
            command=self.open_pc_booking
        ).pack(pady=10)

        Button(
            self.root,
            text="Billing System",
            width=25,
            height=2,
            command=self.open_billing_system
        ).pack(pady=10)

        Button(
            self.root,
            text="Reports",
            width=25,
            height=2,
            command=self.open_reports
        ).pack(pady=10)


        Button(
            self.root,
            text="Exit",
            width=25,
            height=2,
            command=self.root.destroy
        ).pack(pady=10)

        Button(
            self.root,
            text="Advanced Tools",
            width=25,
            height=2,
            command=self.open_tools
        ).pack(pady=10)

    def open_customer_management(self):
            customer_window = Toplevel(self.root)

            CustomerManagement(customer_window)

    def open_pc_booking(self):
        booking_window = Toplevel(self.root)

        PCBooking(booking_window)

    def open_billing_system(self):
        billing_window = Toplevel(self.root)

        BillingSystem(billing_window)

    def open_reports(self):
        report_window = Toplevel(self.root)

        Reports(report_window)

    def open_tools(self):
        tools_window = Toplevel(self.root)

        Tools(tools_window)



if __name__ == "__main__":

    root = Tk()

    app = Dashboard(root)

    root.mainloop()
