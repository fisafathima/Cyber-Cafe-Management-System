from tkinter import *
from tkinter import messagebox

from database.db import connect_db
from gui.dashboard import Dashboard


def login():

    username = username_entry.get()
    password = password_entry.get()

    try:

        conn = connect_db()
        cursor = conn.cursor()

        query = """
        SELECT * FROM users
        WHERE username=%s AND password=%s
        """

        cursor.execute(query, (username, password))

        user = cursor.fetchone()

        if user:

            messagebox.showinfo(
                "Success",
                "Login Successful"
            )

            root.destroy()

            dashboard_root = Tk()

            Dashboard(dashboard_root)

            dashboard_root.mainloop()

        else:

            messagebox.showerror(
                "Error",
                "Invalid Username or Password"
            )

        conn.close()

    except Exception as e:

        messagebox.showerror(
            "Database Error",
            str(e)
        )




root = Tk()

root.title("Cyber Cafe Login")

root.geometry("500x400")

root.config(bg="#1e1e2f")




title = Label(
    root,
    text="☕ Cyber Cafe",
    font=("Arial", 24, "bold"),
    bg="#1e1e2f",
    fg="#00ffd5"
)

title.pack(pady=20)


subtitle = Label(
    root,
    text="Management System",
    font=("Arial", 14),
    bg="#1e1e2f",
    fg="white"
)

subtitle.pack(pady=5)




frame = Frame(
    root,
    bg="#2b2b40",
    padx=30,
    pady=30
)

frame.pack(pady=20)




Label(
    frame,
    text="Username",
    font=("Arial", 12),
    bg="#2b2b40",
    fg="white"
).grid(row=0, column=0, sticky="w", pady=10)

username_entry = Entry(
    frame,
    font=("Arial", 12),
    width=25,
    bd=3
)

username_entry.grid(row=1, column=0, pady=5)




Label(
    frame,
    text="Password",
    font=("Arial", 12),
    bg="#2b2b40",
    fg="white"
).grid(row=2, column=0, sticky="w", pady=10)

password_entry = Entry(
    frame,
    show="*",
    font=("Arial", 12),
    width=25,
    bd=3
)

password_entry.grid(row=3, column=0, pady=5)




Button(
    frame,
    text="LOGIN",
    font=("Arial", 12, "bold"),
    bg="#00ffd5",
    fg="black",
    width=20,
    cursor="hand2",
    command=login
).grid(row=4, column=0, pady=20)


root.mainloop()