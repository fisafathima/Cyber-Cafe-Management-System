from tkinter import *
from tkinter import messagebox

from scraping.package_scraper import get_packages
from networking.notifier import send_notification

from utils.decorators import logger
from utils.closures import cafe_message
from utils.generators import bill_generator


class Tools:

    def __init__(self, root):

        self.root = root

        self.root.title("Advanced Tools")

        self.root.geometry("700x500")

        self.root.config(bg="#1e1e2f")


        Label(
            self.root,
            text="Advanced Tools",
            font=("Arial", 20, "bold"),
            bg="#1e1e2f",
            fg="#00ffd5"
        ).pack(pady=20)


        Button(
            self.root,
            text="Show Scraped Packages",
            width=25,
            bg="#00ffd5",
            command=self.show_packages
        ).pack(pady=10)


        Button(
            self.root,
            text="Send Notification",
            width=25,
            bg="orange",
            command=self.notify
        ).pack(pady=10)


        Button(
            self.root,
            text="Generate Bill Number",
            width=25,
            bg="lightgreen",
            command=self.generate_bill
        ).pack(pady=10)


        self.output = Text(
            self.root,
            width=70,
            height=15
        )

        self.output.pack(pady=20)


        self.bill_gen = bill_generator()


    @logger
    def show_packages(self):

        packages = get_packages()

        self.output.delete(
            1.0,
            END
        )

        for package in packages:

            self.output.insert(
                END,
                package + "\n"
            )


    def notify(self):

        send_notification(
            "Time Over Alert!"
        )

        welcome = cafe_message(
            "Cyber Cafe:"
        )

        msg = welcome(
            "Please logout safely."
        )

        messagebox.showinfo(
            "Notification",
            msg
        )


    def generate_bill(self):

        number = next(
            self.bill_gen
        )

        self.output.insert(
            END,
            f"Bill Number: {number}\n"
        )


if __name__ == "__main__":

    root = Tk()

    app = Tools(root)

    root.mainloop()