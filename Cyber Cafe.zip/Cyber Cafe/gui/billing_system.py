import os

from tkinter import *
from tkinter import ttk, messagebox

from database.db import connect_db
from models.billing import Bill, VIPBill


class BillingSystem:

    def __init__(self, root):

        self.root = root

        self.root.title("Billing System")

        self.root.geometry("700x500")

        self.root.config(bg="#1e1e2f")


        Label(
            self.root,
            text="Billing System",
            font=("Arial", 20, "bold"),
            bg="#1e1e2f",
            fg="#00ffd5"
        ).pack(pady=20)


        form_frame = Frame(self.root, bg="#2b2b40")

        form_frame.pack(pady=10)




        Label(
            form_frame,
            text="Customer Name",
            bg="#2b2b40",
            fg="white"
        ).grid(row=0, column=0, padx=10, pady=10)

        self.name_entry = Entry(form_frame, width=30)

        self.name_entry.grid(row=0, column=1)




        Label(
            form_frame,
            text="Usage Hours",
            bg="#2b2b40",
            fg="white"
        ).grid(row=1, column=0, padx=10, pady=10)

        self.hours_entry = Entry(form_frame, width=30)

        self.hours_entry.grid(row=1, column=1)




        Label(
            form_frame,
            text="Snack Amount",
            bg="#2b2b40",
            fg="white"
        ).grid(row=2, column=0, padx=10, pady=10)

        self.snack_entry = Entry(form_frame, width=30)

        self.snack_entry.grid(row=2, column=1)




        Label(
            form_frame,
            text="Membership",
            bg="#2b2b40",
            fg="white"
        ).grid(row=3, column=0, padx=10, pady=10)

        self.member_box = ttk.Combobox(
            form_frame,
            values=["Normal", "VIP"]
        )

        self.member_box.grid(row=3, column=1)

        self.member_box.current(0)


        Button(
            self.root,
            text="Generate Bill",
            bg="#00ffd5",
            fg="black",
            width=20,
            command=self.generate_bill
        ).pack(pady=20)


        self.result_label = Label(
            self.root,
            text="",
            font=("Arial", 14, "bold"),
            bg="#1e1e2f",
            fg="white"
        )

        self.result_label.pack(pady=10)


    def generate_bill(self):

        try:

            customer_name = self.name_entry.get()

            usage_hours = int(
                self.hours_entry.get()
            )

            snack_amount = int(
                self.snack_entry.get()
            )

            membership = self.member_box.get()




            if membership == "VIP":

                bill = VIPBill(
                    customer_name,
                    usage_hours,
                    snack_amount
                )

            else:

                bill = Bill(
                    customer_name,
                    usage_hours,
                    snack_amount
                )


            total = bill.calculate_total()




            conn = connect_db()

            cursor = conn.cursor()

            query = """
            INSERT INTO bills(
                customer_name,
                usage_hours,
                snack_amount,
                total_amount
            )
            VALUES(%s,%s,%s,%s)
            """

            values = (
                customer_name,
                usage_hours,
                snack_amount,
                total
            )

            cursor.execute(query, values)

            conn.commit()

            conn.close()




            BASE_DIR = os.path.dirname(
                os.path.dirname(__file__)
            )

            file_path = os.path.join(
                BASE_DIR,
                "files",
                "bills.txt"
            )

            os.makedirs(
                os.path.dirname(file_path),
                exist_ok=True
            )

            with open(file_path, "a") as file:

                file.write(
                    f"{customer_name} | Rs.{total}\n"
                )

            bill_text = f"""
            ================================
                    CYBER CAFE BILL
            ================================

            Customer Name : {customer_name}

            Usage Hours   : {usage_hours}

            Snack Amount  : Rs.{snack_amount}

            Membership    : {membership}

            --------------------------------

            Total Bill    : Rs.{total}

            ================================
                    THANK YOU
            ================================
            """

            messagebox.showinfo(
                "Bill Receipt",
                bill_text
            )

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )


if __name__ == "__main__":

    root = Tk()

    app = BillingSystem(root)

    root.mainloop()